package Assign;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class MyClass {

    @Test
    public void sPassed() {
        System.setProperty("webdriver.chrome.driver", "src/main/resources/chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        String URL = "https://www.sans.org/account/create";
        driver.get(URL);
        WebElement fName = driver.findElement(By.id("create-first-name"));
        fName.sendKeys("Muhammad");
        sleep(1000);
        WebElement lName = driver.findElement(By.id("create-last-name"));
        lName.sendKeys("Hozaifa");
        sleep(1000);
        WebElement email = driver.findElement(By.id("create-email"));
        email.sendKeys("hozaifa@pakistan.com");
        sleep(1000);
        WebElement password = driver.findElement(By.id("create-password"));
        password.sendKeys("Paku34$%%%^#stan");
        sleep(1000);
        WebElement confirmPassword = driver.findElement(By.id("create-repeat"));
        confirmPassword.sendKeys("Paku34$%%%^#stan");
        sleep(300);
        WebElement join = driver.findElement(By.xpath("//input[@type='submit']"));
        join.click();
        sleep(4000);
        String expected = "https://www.sans.org/account/create/success";
        String actual = driver.getCurrentUrl();
        Assert.assertEquals(actual, expected, "Failed");
        sleep(1000);
        driver.quit();
    }


    @Test
    public void sFailed() {
        System.setProperty("webdriver.chrome.driver", "src/main/resources/chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        String URL = "https://www.sans.org/account/create";
        driver.get(URL);
        WebElement fName = driver.findElement(By.id("create-first-name"));
        fName.sendKeys("Muhammad");
        sleep(1000);
        WebElement lName = driver.findElement(By.id("create-last-name"));
        lName.sendKeys("Hozaifa");
        sleep(1000);
        WebElement email = driver.findElement(By.id("create-email"));
        email.sendKeys("hozaifa@pakistan.com");
        sleep(1000);
        WebElement password = driver.findElement(By.id("create-password"));
        password.sendKeys("Paku34$%%%^#stan");
        sleep(1000);
        WebElement confirmPassword = driver.findElement(By.id("create-repeat"));
        confirmPassword.sendKeys("Paku34$%%%^#stan");
        sleep(300);
        WebElement join = driver.findElement(By.xpath("//input[@type='submit']"));
        join.click();
        sleep(4000);
        String expected = "https://www.sans.org/";
        String actual = driver.getCurrentUrl();
        Assert.assertEquals(actual, expected, "Failed");
        sleep(1000);
        driver.quit();
    }

    @Test
    public void lPassed() {
        System.setProperty("webdriver.chrome.driver", "src/main/resources/chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        String URL = "https://idp.sans.org/simplesaml/module.php/core/loginuserpass.php?AuthState=_87f6137f4729a306274e7d628cfa146cc0ba9b23b7%3Ahttps%3A%2F%2Fidp.sans.org%2Fsimplesaml%2Fsaml2%2Fidp%2FSSOService.php%3Fspentityid%3Dhttps%253A%252F%252Fwww.sans.org%252Fsimplesaml%252Fmodule.php%252Fsaml%252Fsp%252Fmetadata.php%252Fsans-live-sp%26RelayState%3Dhttps%253A%252F%252Fwww.sans.org%252Faccount%252Floginsso%26cookieTime%3D1596628143";
        driver.get(URL);
        WebElement email = driver.findElement(By.id("username"));
        email.sendKeys("hozaifa@pakistan.com");
        sleep(1000);
        WebElement password = driver.findElement(By.id("password"));
        password.sendKeys("Paku34$%%%^#stan");
        sleep(1000);
        WebElement join = driver.findElement(By.id("regularsubmit"));
        join.click();
        sleep(4000);
        WebElement succes=driver.findElement(By.xpath("//div[@class='message message-error']"));
        String expected = "Incorrect username or password.";
        String actual = succes.getText();
        Assert.assertEquals(actual, expected, "Failed");
        sleep(1000);
        driver.quit();
    }


    @Test
    public void lFailed() {
        System.setProperty("webdriver.chrome.driver", "src/main/resources/chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        String URL = "https://idp.sans.org/simplesaml/module.php/core/loginuserpass.php?AuthState=_87f6137f4729a306274e7d628cfa146cc0ba9b23b7%3Ahttps%3A%2F%2Fidp.sans.org%2Fsimplesaml%2Fsaml2%2Fidp%2FSSOService.php%3Fspentityid%3Dhttps%253A%252F%252Fwww.sans.org%252Fsimplesaml%252Fmodule.php%252Fsaml%252Fsp%252Fmetadata.php%252Fsans-live-sp%26RelayState%3Dhttps%253A%252F%252Fwww.sans.org%252Faccount%252Floginsso%26cookieTime%3D1596628143";
        driver.get(URL);
        WebElement email = driver.findElement(By.id("username"));
        email.sendKeys("hozaifa@pakistan.com");
        sleep(1000);
        WebElement password = driver.findElement(By.id("password"));
        password.sendKeys("Paku34$%%%^#stan");
        sleep(1000);
        WebElement join = driver.findElement(By.id("regularsubmit"));
        join.click();
        sleep(4000);
        String expected = "https://www.sans.org/";
        String actual = driver.getCurrentUrl();
        Assert.assertEquals(actual, expected, "Failed");
        sleep(1000);
        driver.quit();
    }



    public void sleep(long time) {
        try {
            Thread.sleep(time);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

}